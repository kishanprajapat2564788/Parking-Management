  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; 2021 KISHAN
                    </div>
                    <div class="col-sm-6 text-right">
                     Parking Management System
                    </div>
                </div>
            </div>
        </footer>